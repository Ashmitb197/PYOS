from tkinter import*

tk = Tk()
tk.geometry("1000x700")
tk.config(bg="black")
def rockl():
    rock = PhotoImage(file = "F:\\School project\\applications\Rockpaper\\img\\rock.png")
    rock_lb = Label(tk, image = rock)
    rock_lb.place(x= 0,y=10)



tk.mainloop()